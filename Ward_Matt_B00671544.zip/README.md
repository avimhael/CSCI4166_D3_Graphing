# Visualization CSCI 4166.03
## Graphing Assignment
### February 2021
### Matt Ward B00671544

#### This is best run using a local server to view - MAMP or something similar. 
#### Simple run your server and browse to localhost (or your htdocs folder).
#### When you have the list of files here, simply browser into the directory and view.

#### File.doc is a dummy file to emulate the downloading of a file via the download button on the left of the page

## Notes:

#### Mostly complete. 
#### (1) Did not attempt the 'stack of papers' in the top-left graphic for lack of time.  
#### (2) Was following / modifying an existing implementation of the tornado graph found here by Lucas Matteis #### using V3 of D3.js : https://bl.ocks.org/lmatteis/d0f7533895da2e59cd6f62f3589fd8eb
#### I managed to get it updated and working with V6 of D3.js but ran out of time for further formatting work.

#### Learned a lot this assignment, thanks!

